#include <iostream>
#include "Newman/Newman.hpp"

int main(int argc, char** argv) {
	std::cout << "-*-*-*-*-*-*-*-*-*\n\n" 
		<< "This is a test for the integration of Newman library\n"
		<< "into another, existing project (in the context of VS)\n"
		<< "\nNewman is a library to send email through SMTP using .eml\n"
		<< "e-mail files and possibly an SSL certificate in .pem format\n\n"
		<< "-*-*-*-*-*-*-*-*-*-*-*"
		<< std::endl;
	Newman::sendMail(argc, argv);
}
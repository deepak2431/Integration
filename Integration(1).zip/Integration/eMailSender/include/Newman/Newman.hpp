#pragma once

namespace Newman {
	int sendMail(int, char**);
}